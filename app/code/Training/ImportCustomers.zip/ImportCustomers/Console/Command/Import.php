<?php

declare(strict_types=1);

namespace Training\ImportCustomers\Console\Command;

use Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Console\Cli;
use Magento\Framework\Filesystem;
use Magento\Framework\App\State;
use Magento\Framework\App\Area;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Training\ImportCustomers\Model\Customer;

Class Import extends Command
{
    private $filesystem;
    private $customer;
    private $state;

    const INPUT_FILE = 'file';
    
    public function __construct(
        Filesystem $filesystem,
        Customer $customer,
        State $state,
        \Magento\Framework\Filesystem\Io\File $filesystemIo
    ) {
    parent::__construct();
        $this->filesystem = $filesystem;
        $this->customer = $customer;
        $this->state = $state;
        $this->mediaDirectory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $this->filesystemIo = $filesystemIo;
    }


    protected function configure(){
        parent::configure();
        
        $this->setName('customer:importer');
        $this->setDescription('Customer Import Example');
        $this->addOption(
            'profile',
            null,
            InputOption::VALUE_REQUIRED,
            'PROFILE'
        );
        $this->addArgument(
            self::INPUT_FILE,
            InputArgument::REQUIRED,
            'description'
        );

        
    }
    protected function execute(InputInterface $input, OutputInterface $output){
        try {

            $filename = $input->getArgument(self::INPUT_FILE);

            $format = $input->getOption('profile');

            /*if($format != 'csv' || $format !='json'){
                $output->writeln('<info>Provide Valid format.</info>');
            }*/

            //$output->writeln($filename);

           /* $result = $this->mediaDirectory->copyFile(
                $this->getPath(self::TMP_SUBDIR, $filename),
                $this->getPath($subdirToSave, $filename)
            );*/


            $filePath  = '/Downloads/sample.csv';//source file
            $mediaDir = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA);
            $copyFileFullPath = $mediaDir->getAbsolutePath() . 'fixtures/customers.csv';
            //$copyFileFullPath  = '/var/www/html//pub/media/folderName/newImagesName.jpg'; // destination file

            $fileLoca = $this->filesystemIo->cp($filePath, $copyFileFullPath);

            //$output->writeln($copyFileFullPath);

            /*$this->state->setAreaCode(Area::AREA_GLOBAL);
       
               
            $this->customer->install($fileLoca, $output);
       
            return Cli::RETURN_SUCCESS;*/
        } catch (Exception $e) {
            $msg = $e->getMessage();
            $output->writeln("<error>$msg</error>", OutputInterface::OUTPUT_NORMAL);
            return Cli::RETURN_FAILURE;
        }
    }
    
}
